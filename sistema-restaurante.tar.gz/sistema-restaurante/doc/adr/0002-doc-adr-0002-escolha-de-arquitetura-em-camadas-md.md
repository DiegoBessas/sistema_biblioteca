# 2. doc/adr/0002-escolha-de-arquitetura-em-camadas.md

Date: 2025-10-03

## Status

Accepted

## Context

The issue motivating this decision, and any context that influences or constrains the decision.

## Decision

The change that we're proposing or have agreed to implement.

## Consequences

What becomes easier or more difficult to do and any risks introduced by the change that will need to be mitigated.
